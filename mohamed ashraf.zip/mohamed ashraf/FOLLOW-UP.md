# Implementation:

### Q) What libraries did you add to the frontend? What are they used for?
i did not use any libraries

### Q) What's the command to start the application locally?

(Default) `npm start`

---

# General:

### Q) If you had more time, what further improvements or new features would you add?
may be change the color 

### Q) Which parts are you most proud of? And why?
cards because all depends on it

### Q) Which parts did you spend the most time with? What did you find most difficult?
arrangement of sites in the card

### Q) How did you find the test overall? Did you have any issues or have difficulties completing?If you have any suggestions on how we can improve the test, we'd love to hear them.
good and need from the person high concentration
